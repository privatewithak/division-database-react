import { BASE_STYLES } from "./data/themes"
import LayoutBttn from './reusables/LayoutBttn'
import mockData from "./data/layoutMock"
import { useState } from "react"
import { useCallback } from "react"
import type { MockData } from "./data/layoutMock"
import { AnimatePresence, motion } from "framer-motion"
export default function Layout({ mode }: { mode: 'CCA' | 'OTA' }) {

    const [selectedDiv, setSelectedDiv] = useState<string | null>(null);
    const [selectedRank, setSelectedRank] = useState<MockData['rank'] | null>(null);

    const modeData = mockData.filter(user => user.typeID === mode);
    const divisions = Array.from(new Set(modeData.map(user => user.division)));
    const ranks = selectedDiv ? Array.from(new Set(modeData.filter(user => user.division === selectedDiv).map(user => user.rank))) : [];
   

     const filteredUsers = modeData.filter(user => {
        if (selectedDiv && user.division !== selectedDiv) return false;
        if (selectedRank && user.rank !== selectedRank) return false;
        return true;
     });
    
    const switchDivision = useCallback((division: string) => {
        setSelectedDiv(prev => division === prev ? null : division);
        setSelectedRank(null);
    }, [setSelectedDiv, setSelectedRank]);

    return (
        <>
            
            <main className="col-span-12 md:col-span-9 lg:col-span-10 min-h-full w-full">
                
                <div className="mx-auto w-full max-w-5xl">
                    <AnimatePresence mode='wait'>
                <motion.div key={mode} initial={{opacity: 0, y:10, filter: 'blur(6px'}} animate={{opacity: 1, y: 0, filter: 'blur(0px)'}} exit={{opacity: 0, y: -10, filter: 'blur(6px)'}} transition={{duration: 0.22, ease: 'easeOut'}} className={'w-full mx-auto rounded-lg border border-white/10 bg-white/10 backdrop-blur-xl py-4 mt-2' + ' ' + BASE_STYLES[mode]}>
                    <div className="text-white text-2xl font-mono text-center after:content-[''] after:block after:w-full after:h-0.75 after:bg-gray-500/40 after:mt-2">
                        <h3>Dashboard</h3>
                    </div>
                        <div className="flex flex-wrap gap-6 mt-2 justify-center w-full px-4" >
                        {mode === 'CCA' ? (
                            <>
                                <LayoutBttn isActive={selectedDiv === 'JURY'} mode={mode} onClick={() => switchDivision('JURY')}>JURY</LayoutBttn>
                                <LayoutBttn isActive={selectedDiv === 'SPEAR'} mode={mode} onClick={() => switchDivision('SPEAR')}>SPEAR</LayoutBttn>
                                <LayoutBttn isActive={selectedDiv === 'RAZOR'} mode={mode} onClick={() => switchDivision('RAZOR')}>RAZOR</LayoutBttn>
                                <LayoutBttn isActive={selectedDiv === 'ACADEMY'} mode={mode} onClick={() => switchDivision('ACADEMY')}>ACADEMY</LayoutBttn>
                                </>
                        ) : (
                                <>
                                    <LayoutBttn isActive={selectedDiv === 'ECHO'} mode={mode} onClick={() => switchDivision('ECHO')}>ECHO</LayoutBttn>
                                    <LayoutBttn isActive={selectedDiv === 'DAGGER'} mode={mode} onClick={() => switchDivision('DAGGER')}>DAGGER</LayoutBttn>
                                    <LayoutBttn isActive={selectedDiv === 'RANGER'} mode={mode} onClick={() => switchDivision('RANGER')}>RANGER</LayoutBttn>
                                    <LayoutBttn isActive={selectedDiv === 'KING'} mode={mode} onClick={() => switchDivision('KING')}>KING</LayoutBttn>
                                    <LayoutBttn isActive={selectedDiv === 'PHANTOM'} mode={mode} onClick={() => switchDivision('PHANTOM')}>PHANTOM</LayoutBttn>
                                    </>
                    )}
                        </div>
                        <div className="flex flex-row w-full mt-4 rounded-2xl p-4 m-4 relative max-w-37/40 mx-auto gap-4 h-full">
                                <div className="flex-1 flex-col flex bg-white/10 p-2 rounded-2xl max-w-4/10 overflow-y gap-2">{ranks.map(rank => (
                                    <LayoutBttn className="w-8/10 mx-auto h-12 text-center" key={rank} isActive={selectedRank === rank} mode={mode} onClick={() => setSelectedRank(rank)}>
                                        {rank}
                                    </LayoutBttn>
                                ))}</div>
                                <div className="flex-1 flex-col flex">{filteredUsers.length === 0 ? (<p className="text-white/50 text-center">No users found</p>) : (
                                    <ul className="flex flex-col gap-2">
                                     {filteredUsers.map(user => (
                                        <li key={user.RobloxUserId} className="text-white bg-white/10 rounded-2xl p-2 hover:bg-white/15 transition-colors">
                                            <p className="font-semibold">{user.username}</p>
                                            <p className="text-sm text-white/70">UserID: {user.RobloxUserId} | Division: {user.division} | Rank: {user.rank}</p>
                                        </li>
                                     ))}
                                    </ul>
                                )}</div>
                </div>
                        </motion.div>
                    </AnimatePresence>
                    </div>
                    
                </main>
                
        </>
    )
}