export type MockData = {
  typeID: 'CCA' | 'OTA';
  RobloxUserId: number;
  username: string;
  division: string;
  rank: 'D5' | 'D4' | 'D3' | 'D2' | 'D1' | 'Tier 3' | 'Tier 2' | 'Tier 1';
};

const mockData: MockData[] = [
  {
    typeID: 'CCA',
    RobloxUserId: 123456789,
    username: 'PlayerOne',
    division: 'JURY',
    rank: 'D5',
  },
    {
    typeID: 'CCA',
    RobloxUserId: 123456789,
    username: 'PlayerOne',
    division: 'JURY',
    rank: 'D4',
  },
  {
    typeID: 'OTA',
    RobloxUserId: 987654321,
    username: 'PlayerTwo',
    division: 'ECHO',
    rank: 'Tier 1',
  },
  {
    typeID: 'CCA',
    RobloxUserId: 112233445,
    username: 'PlayerThree',
    division: 'RAZOR',
    rank: 'D3',
  },
  {
    typeID: 'OTA',
    RobloxUserId: 556677889,
    username: 'PlayerFour',
    division: 'RANGER',
    rank: 'Tier 2',
  },
  {
    typeID: 'CCA',
    RobloxUserId: 998877665,
    username: 'PlayerFive',
    division: 'SPEAR',
    rank: 'D1',
  },
];
export default mockData;